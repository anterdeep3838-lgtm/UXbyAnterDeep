import sys,json,asyncio
from playwright.async_api import async_playwright
# jobs json: [{n,route,w,h,d,ls:{k:v},js:"...",sel:"#x" (scroll to),wait}]
JOBS=json.load(open(sys.argv[1])); OUT=sys.argv[2] if len(sys.argv)>2 else 'cap'
BASE={'cookies':{'essential':True,'analytics':False,'personal':False,'marketing':False,'at':'2026-10-25T10:00:00Z'},'compare':[]}
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for j in JOBS:
            ls={**BASE,**j.get('ls',{})}
            ctx=await b.new_context(viewport={'width':j['w'],'height':j['h']},device_scale_factor=j.get('d',2),is_mobile=j.get('mob',False),has_touch=j.get('mob',False))
            await ctx.add_init_script("(()=>{const L=%s;for(const k in L)localStorage.setItem('op:'+k,JSON.stringify(L[k]));})()"%json.dumps(ls))
            pg=await ctx.new_page()
            await pg.goto('file:///home/claude/outpace/site/index.html'+j['route']); await pg.wait_for_timeout(1800)
            if j.get('sel'): await pg.evaluate("(s)=>{const e=document.querySelector(s);window.scrollTo(0,e.getBoundingClientRect().top+scrollY-(%d))}"%j.get('off',90),j['sel']); await pg.wait_for_timeout(1400)
            if j.get('y'): await pg.evaluate(f"window.scrollTo(0,{j['y']})"); await pg.wait_for_timeout(1400)
            await pg.mouse.move(5,j['h']-5)
            if j.get('hover'): await pg.hover(j['hover']); await pg.wait_for_timeout(900)
            if j.get('click'):
                for c in j['click']: await pg.click(c); await pg.wait_for_timeout(900)
            if j.get('js'): await pg.evaluate(j['js']); await pg.wait_for_timeout(900)
            await pg.wait_for_timeout(j.get('wait',500))
            await pg.screenshot(path=f"{OUT}/{j['n']}.png"); print(j['n']); await ctx.close()
        await b.close()
asyncio.run(main())

import sys, os
src = '/home/claude/worth/deck/'
parts = [p for p in ['p1', 'p2', 'p3', 'p4'] if os.path.exists(src + p + '.html')]
css = ''.join(open(src + p + '.css').read() for p in parts)
h = open(src + 'head.html').read().replace('</style>', css + '\n</style>', 1)
body = ''.join(open(src + p + '.html').read() for p in parts)
nxt = {1: 'Next: existing solutions, success criteria, strategy and scope, design process, product evolution (SpendWise to Worth), the core journey and information architecture.',
       2: 'Next: the centrepiece — dashboard and Money Left, transaction entry, analysis, budgets and savings.',
       3: 'Next: key decisions, iterations, UX laws, typography, product states, financial trust, AI workflow, results and the closing slide.'}
if not (len(sys.argv) > 1 and sys.argv[1] == 'final'):
    n = len(parts)
    body += f'<div class="next"><span style="font:600 15px/1 var(--f);letter-spacing:.12em;text-transform:uppercase;color:var(--blue-hi)">Phase {n} of 4</span><br><br><b>{nxt[n]}</b></div>\n'
open(os.environ.get('OUT','/home/claude/site/worth.html'), 'w').write(h + body + open(src + 'foot.html').read())
print('built', parts)
